# Recipe Service — вариант 23

Учебный REST API на **C++ + userver + PostgreSQL** для варианта **23: система управления рецептами**.

## Что реализовано

### Основной функционал
- регистрация пользователя;
- логин и получение bearer token;
- поиск пользователя по логину;
- поиск пользователя по маске имени и фамилии;
- создание рецепта;
- получение списка рецептов и поиск по названию;
- добавление ингредиента в рецепт;
- получение ингредиентов рецепта;
- получение собственных рецептов пользователя;
- добавление рецепта в избранное;
- получение избранных рецептов.

### Оптимизации производительности
#### Кеширование
Реализован in-memory cache по стратегии **Cache-Aside** для endpoint:
- `GET /api/v1/users/by-login`
- `GET /api/v1/users/search`
- `GET /api/v1/recipes`
- `GET /api/v1/recipes/{recipe_id}/ingredients`
- `GET /api/v1/users/me/recipes`
- `GET /api/v1/users/me/favorites`

В ответах для кэшируемых endpoint добавлен заголовок:
- `X-Cache: MISS`
- `X-Cache: HIT`

#### Rate limiting
Для `POST /api/v1/auth/login` реализован **Fixed Window Counter**:
- лимит: **5 запросов / 60 секунд**;
- при превышении возвращается **429 Too Many Requests**;
- заголовки:
  - `X-RateLimit-Limit`
  - `X-RateLimit-Remaining`
  - `X-RateLimit-Reset`

## Структура проекта
- `src/components/response_cache.*` — компонент кэширования;
- `src/components/rate_limiter.*` — компонент rate limiting;
- `src/storage/recipe_storage.*` — PostgreSQL storage;
- `src/handlers/*.cpp` — HTTP handlers;
- `performance_design.md` — описание стратегии кеширования и rate limiting;
- `schema.sql` — схема БД и индексы;
- `docker-compose.yaml` — локальный запуск приложения и PostgreSQL.

## Запуск через Docker Compose
```bash
docker compose up --build
```

Сервис будет доступен на:
```text
http://localhost:8080
```

## Примеры запросов

### Регистрация
```bash
curl -X POST http://localhost:8080/api/v1/auth/register \
  -H 'Content-Type: application/json' \
  -d '{
    "login": "chef1",
    "first_name": "Ivan",
    "last_name": "Petrov",
    "password": "secret"
  }'
```

### Логин
```bash
curl -X POST http://localhost:8080/api/v1/auth/login \
  -H 'Content-Type: application/json' \
  -d '{
    "login": "chef1",
    "password": "secret"
  }'
```

### Получение списка рецептов
```bash
curl 'http://localhost:8080/api/v1/recipes?title=soup'
```

### Создание рецепта
```bash
curl -X POST http://localhost:8080/api/v1/recipes \
  -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <TOKEN>' \
  -d '{
    "title": "Borscht",
    "description": "Classic soup"
  }'
```

## Тесты
В testsuite добавлены тесты на:
- базовую функциональность API;
- `X-Cache: HIT/MISS`;
- инвалидацию кэша;
- возврат `429` и rate-limit заголовков.

## Примечания
- Для простоты в этом домашнем задании используется **in-memory** кэш вместо Redis.
- Инвалидация сделана частично по префиксам, чтобы сохранить корректность данных и не усложнять код.
